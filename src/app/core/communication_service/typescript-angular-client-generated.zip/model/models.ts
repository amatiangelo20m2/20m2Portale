export * from './whatsAppConfigurationDTO';
