export * from './whatsAppConfigurationController.service';
import { WhatsAppConfigurationControllerService } from './whatsAppConfigurationController.service';
export const APIS = [WhatsAppConfigurationControllerService];
